"""
Юзербот-клиент (Telethon) на строке сессии.

Bot API не отдаёт атрибуты уникальных подарков (фон/узор/модель/
редкость) — это доступно только через MTProto-методы для
"unique star gifts". Схема TL для этого раздела API менялась
несколько раз за последний год, так что НАЗВАНИЯ ФУНКЦИЙ И ПОЛЕЙ
НИЖЕ НУЖНО СВЕРИТЬ с той версией Telethon, которую ты реально
поставишь (`python -c "from telethon.tl import functions;
print([x for x in dir(functions.payments) if 'Gift' in x])"`),
я даю рабочий каркас, а не гарантированно точные имена методов.

Логика:
1. Из ссылки вида t.me/nft/Slug-123 достаём slug.
2. Резолвим уникальный подарок по slug.
3. Вытаскиваем attributes: model, backdrop (фон), pattern (узор/символ),
   а также redeem/collectible number и общий тираж модели/паттерна.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from telethon import TelegramClient
from telethon.sessions import StringSession

from config import settings

_client = TelegramClient(StringSession(settings.session_string),
                          settings.api_id, settings.api_hash)

_LINK_RE = re.compile(r"(?:https?://)?t\.me/nft/([A-Za-z0-9_\-]+)")


@dataclass
class GiftAttributes:
    slug: str
    title: str
    model_name: str
    model_rarity_permille: int | None
    backdrop_name: str
    backdrop_rarity_permille: int | None
    pattern_name: str
    pattern_rarity_permille: int | None
    number: int | None
    availability_total: int | None


def parse_slug(link_or_slug: str) -> str:
    link_or_slug = link_or_slug.strip()
    m = _LINK_RE.search(link_or_slug)
    if m:
        return m.group(1)
    # уже похоже на голый slug, например "PlushPepe-1"
    if re.match(r"^[A-Za-z0-9_\-]+$", link_or_slug):
        return link_or_slug
    raise ValueError("Не похоже на ссылку/slug NFT-подарка")


async def start():
    if not _client.is_connected():
        await _client.start()


async def stop():
    if _client.is_connected():
        await _client.disconnect()


async def get_gift_attributes(link_or_slug: str) -> GiftAttributes:
    """
    Достаёт атрибуты уникального подарка по ссылке/slug.

    ЗАМЕЧАНИЕ: конкретный вызов ниже — заглушка под реальный MTProto-метод.
    На момент написания в TL-схеме это что-то в районе
    `functions.payments.GetUniqueStarGiftRequest` /
    `functions.payments.GetSavedStarGiftRequest`, но имя и структура
    ответа отличаются между релизами Telegram/Telethon — проверь
    актуальную схему (`telethon.tl.functions.payments`) перед запуском
    и подставь реальный вызов сюда.
    """
    slug = parse_slug(link_or_slug)
    await start()

    from telethon.tl import functions  # локальный импорт, чтобы было видно, что трогать

    result = await _client(functions.payments.GetUniqueStarGiftRequest(slug=slug))
    gift = result.gift

    model = backdrop = pattern = None
    for attr in gift.attributes:
        cname = attr.__class__.__name__
        if "Model" in cname:
            model = attr
        elif "Backdrop" in cname:
            backdrop = attr
        elif "Pattern" in cname or "Symbol" in cname:
            pattern = attr

    def rarity(attr):
        return getattr(attr, "rarity_permille", None) if attr else None

    return GiftAttributes(
        slug=slug,
        title=getattr(gift, "title", slug),
        model_name=getattr(model, "name", "неизвестно") if model else "неизвестно",
        model_rarity_permille=rarity(model),
        backdrop_name=getattr(backdrop, "name", "неизвестно") if backdrop else "неизвестно",
        backdrop_rarity_permille=rarity(backdrop),
        pattern_name=getattr(pattern, "name", "неизвестно") if pattern else "неизвестно",
        pattern_rarity_permille=rarity(pattern),
        number=getattr(gift, "num", None),
        availability_total=getattr(gift, "availability_total", None),
    )
