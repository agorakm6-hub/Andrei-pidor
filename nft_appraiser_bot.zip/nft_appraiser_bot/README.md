# NFT Appraiser Bot

Telegram-бот, оценивающий NFT-подарки (фон/узор/модель) через
юзербот-сессию (MTProto) + витрину на aiogram.

## Установка

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Заполни `.env`:
- `BOT_TOKEN` — от @BotFather
- `API_ID` / `API_HASH` — с https://my.telegram.org
- `SESSION_STRING` — Telethon StringSession твоего аккаунта
  (сгенерировать: `python -c "from telethon.sync import TelegramClient; from telethon.sessions import StringSession; print(TelegramClient(StringSession(), API_ID, 'API_HASH').start().session.save())"`)

Эмодзи (`EMOJI_STAR` и т.д.) — необязательны. Без них бот использует
обычные ⭐ 💎 🔍 ◀️ ✨. Если позже захочешь premium custom-эмодзи —
владелец бота должен иметь Telegram Premium (обязательное условие
Bot API), а id эмодзи достаёшь, переслав сообщение с ним боту вроде
`@S0N59_EmojiIDBot` (код: github.com/S0N59/Telegram-Emoji-ID).

## Запуск

```bash
python bot.py
```

## Деплой на Render

Бот работает через long polling — на Render его нужно завести как
**Background Worker**, не Web Service (тому нужен открытый порт, а
у бота его нет).

1. Залей папку `nft_appraiser_bot` в свой репозиторий на GitHub
   (`.env` в репозиторий НЕ попадёт — он в `.gitignore`, это правильно,
   секреты туда лить нельзя).
2. На Render: **New → Background Worker**, подключаешь репозиторий.
3. Build Command: `pip install -r requirements.txt`
   Start Command: `python bot.py` (или просто оставь — есть `Procfile`).
4. Во вкладке **Environment** руками впиши те же переменные, что в
   `.env.example`: `BOT_TOKEN`, `API_ID`, `API_HASH`, `SESSION_STRING`
   (и опционально `EMOJI_*`).
5. Deploy — Render сам поставит зависимости и запустит `bot.py`.

## Что нужно доделать самому (честно, без вымышленных API)

1. **`userbot.py`** — вызов `functions.payments.GetUniqueStarGiftRequest`
   каркасный; сверь точное имя метода/поля под установленную версию
   Telethon (TL-схема этого раздела меняется).
2. **`pricing.py`** — `MockPriceProvider` — заглушка. Нужно написать
   реальный провайдер floor-цен по атрибутам (модель/фон/паттерн) —
   на основе API/данных Portals Market, Tonnel Relayer или getgems.
   У меня нет подтверждённых актуальных эндпоинтов, поэтому не стал
   их придумывать — подставь реальные при интеграции.
3. Курс `TON_TO_STARS` в `pricing.py` — актуализируй перед запуском.

## Структура

- `bot.py` — точка входа, хендлеры, весь UI-флоу (одно редактируемое сообщение)
- `userbot.py` — получение атрибутов подарка через MTProto
- `pricing.py` — формула оценки цены
- `raw_api.py` — прямые HTTP-запросы к Bot API для цветных кнопок
- `animation.py` — анимация «сканирую...» через edit_message_text
- `states.py` — FSM состояния
