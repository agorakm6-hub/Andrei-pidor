"""
Логика оценки цены.

Разделено на два слоя:

1. PriceProvider — источник флор-цен по атрибутам (модель/фон/паттерн)
   конкретной коллекции подарков. У Telegram самого таких цен нет —
   их считают маркетплейсы (Portals Market, Tonnel Relayer, getgems).
   У меня нет подтверждённых актуальных эндпоинтов их API, поэтому
   ниже — интерфейс + заглушка (MockPriceProvider). Реальный провайдер
   нужно написать под конкретный маркетплейс: либо через официальный
   API (если есть публичный), либо анализируя сетевые запросы их
   Mini App через тот же юзербот/браузер. Не подставляй сюда
   придуманные урлы — сначала проверь их своими руками.

2. estimate_price() — сама формула агрегации, по описанию:
   - смотрим цену фона (если фон сам по себе ценится — берём его)
   - иначе смотрим модель, берём её минимальную (floor) цену
   - усредняем то, что нашли по фону и по модели
   - если фон монохромный (совпадает по цвету с подарком) — бонус к цене
   - реже (ниже rarity_permille) => дороже
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from userbot import GiftAttributes


@dataclass
class AttributeFloor:
    ton_floor: float | None          # флор в TON, None если данных нет
    stars_floor: float | None        # флор в звёздах, если применимо


class PriceProvider(Protocol):
    async def model_floor(self, collection: str, model_name: str) -> AttributeFloor: ...
    async def backdrop_floor(self, collection: str, backdrop_name: str) -> AttributeFloor: ...
    async def pattern_floor(self, collection: str, pattern_name: str) -> AttributeFloor: ...


class MockPriceProvider:
    """Заглушка для разработки/тестов UI, пока не подключён реальный источник."""

    async def model_floor(self, collection: str, model_name: str) -> AttributeFloor:
        return AttributeFloor(ton_floor=None, stars_floor=None)

    async def backdrop_floor(self, collection: str, backdrop_name: str) -> AttributeFloor:
        return AttributeFloor(ton_floor=None, stars_floor=None)

    async def pattern_floor(self, collection: str, pattern_name: str) -> AttributeFloor:
        return AttributeFloor(ton_floor=None, stars_floor=None)


TON_TO_STARS = 250  # ПРИМЕРНЫЙ курс, подставь актуальный при запуске


@dataclass
class PriceEstimate:
    ton_price: float | None
    stars_price: int | None
    confidence: str          # "low" | "medium" | "high" — честно показываем пользователю
    breakdown: dict[str, str]


def _rarity_multiplier(permille: int | None) -> float:
    """Чем реже атрибут (меньше permille), тем выше множитель."""
    if not permille:
        return 1.0
    if permille <= 5:
        return 2.5
    if permille <= 20:
        return 1.8
    if permille <= 50:
        return 1.4
    if permille <= 100:
        return 1.15
    return 1.0


async def estimate_price(gift: GiftAttributes, collection: str,
                          provider: PriceProvider,
                          monochrome: bool = False) -> PriceEstimate:
    model_floor = await provider.model_floor(collection, gift.model_name)
    backdrop_floor = await provider.backdrop_floor(collection, gift.backdrop_name)

    candidates: list[float] = []
    breakdown: dict[str, str] = {}

    if backdrop_floor.ton_floor:
        candidates.append(backdrop_floor.ton_floor)
        breakdown["фон"] = f"{backdrop_floor.ton_floor:.2f} TON"
    else:
        breakdown["фон"] = "нет данных по этому фону — не влияет на цену"

    if model_floor.ton_floor:
        m = model_floor.ton_floor * _rarity_multiplier(gift.model_rarity_permille)
        candidates.append(m)
        breakdown["модель"] = f"{m:.2f} TON (floor {model_floor.ton_floor:.2f} × редкость)"
    else:
        breakdown["модель"] = "нет данных по этой модели"

    if not candidates:
        return PriceEstimate(
            ton_price=None, stars_price=None, confidence="low",
            breakdown={**breakdown, "итог": "недостаточно рыночных данных для оценки"},
        )

    base = sum(candidates) / len(candidates)

    if monochrome:
        base *= 1.15
        breakdown["монохром"] = "+15% (фон в цвет подарка)"

    confidence = "high" if len(candidates) == 2 else "medium"

    return PriceEstimate(
        ton_price=round(base, 2),
        stars_price=round(base * TON_TO_STARS),
        confidence=confidence,
        breakdown=breakdown,
    )
