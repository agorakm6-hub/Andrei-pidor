from aiogram.fsm.state import State, StatesGroup


class AppraiseStates(StatesGroup):
    waiting_link = State()
