import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()


def _get(name: str, required: bool = True) -> str:
    val = os.getenv(name, "")
    if required and not val:
        raise RuntimeError(f"Переменная окружения {name} не задана (см. .env.example)")
    return val


@dataclass(frozen=True)
class Settings:
    bot_token: str
    api_id: int
    api_hash: str
    session_string: str
    emoji_star: str
    emoji_scan: str
    emoji_back: str
    emoji_ton: str
    emoji_ok: str


def load_settings() -> Settings:
    return Settings(
        bot_token=_get("BOT_TOKEN"),
        api_id=int(_get("API_ID")),
        api_hash=_get("API_HASH"),
        session_string=_get("SESSION_STRING"),
        emoji_star=_get("EMOJI_STAR", required=False) or "⭐",
        emoji_scan=_get("EMOJI_SCAN", required=False) or "🔍",
        emoji_back=_get("EMOJI_BACK", required=False) or "◀️",
        emoji_ton=_get("EMOJI_TON", required=False) or "💎",
        emoji_ok=_get("EMOJI_OK", required=False) or "✨",
    )


settings = load_settings()
