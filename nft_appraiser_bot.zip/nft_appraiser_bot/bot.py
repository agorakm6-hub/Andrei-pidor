import asyncio
import logging

from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import Message, CallbackQuery

import raw_api
import userbot
from animation import ScanAnimation
from config import settings
from pricing import MockPriceProvider, estimate_price
from states import AppraiseStates
from userbot import get_gift_attributes

logging.basicConfig(level=logging.INFO)

bot = Bot(token=settings.bot_token)
dp = Dispatcher(storage=MemoryStorage())

price_provider = MockPriceProvider()  # заменить на реальный провайдер, когда он готов

WELCOME_TEXT = (
    f"Привет {settings.emoji_ok}\n\n"
    "Пришли ссылку на свой NFT-подарок — я гляну фон, узор и модель "
    "и посчитаю честную рыночную цену."
)

START_KB = raw_api.keyboard([
    [raw_api.button("Оценить свой NFT", "appraise", style="success")],
])

ASK_LINK_TEXT = "Скинь ссылку на NFT-подарок (t.me/nft/...)"

BACK_KB = raw_api.keyboard([
    [raw_api.button(f"{settings.emoji_back} Назад", "appraise", style="primary")],
])


@dp.message(CommandStart())
async def on_start(message: Message):
    await raw_api.send_message(message.chat.id, WELCOME_TEXT, START_KB)


@dp.callback_query(F.data == "appraise")
async def on_appraise(call: CallbackQuery, state: FSMContext):
    await state.set_state(AppraiseStates.waiting_link)
    await state.update_data(prompt_message_id=call.message.message_id)
    await raw_api.edit_message_text(call.message.chat.id, call.message.message_id, ASK_LINK_TEXT)
    await call.answer()


@dp.message(AppraiseStates.waiting_link)
async def on_link(message: Message, state: FSMContext):
    data = await state.get_data()
    chat_id = message.chat.id
    target_message_id = data.get("prompt_message_id")

    # редактируем существующее сообщение-приглашение, а не плодим новые;
    # само сообщение пользователя со ссылкой можно тихо удалить для чистоты чата
    try:
        await bot.delete_message(chat_id, message.message_id)
    except Exception:
        pass

    anim = ScanAnimation(chat_id, target_message_id)
    anim.start()

    try:
        gift = await get_gift_attributes(message.text)
        # collection нужно определять по названию/коллекции подарка —
        # подставь реальную привязку slug -> коллекция под свою логику
        collection = gift.title.split("-")[0] if "-" in gift.title else gift.title
        monochrome = gift.backdrop_name.lower() in gift.title.lower()

        estimate = await estimate_price(gift, collection, price_provider, monochrome)
    except Exception as e:
        await anim.stop()
        await raw_api.edit_message_text(
            chat_id, target_message_id,
            f"Не получилось разобрать эту ссылку {settings.emoji_scan}\n{e}",
            BACK_KB,
        )
        await state.clear()
        return

    await anim.stop()

    lines = [
        f"<b>{gift.title}</b> #{gift.number or '?'}",
        "",
        f"Модель: {gift.model_name} ({_pct(gift.model_rarity_permille)})",
        f"Фон: {gift.backdrop_name} ({_pct(gift.backdrop_rarity_permille)})",
        f"Узор: {gift.pattern_name} ({_pct(gift.pattern_rarity_permille)})",
        "",
    ]

    if estimate.ton_price:
        lines.append(f"Цена: ~{estimate.ton_price} TON {settings.emoji_ton}")
        lines.append(f"В звёздах: ~{estimate.stars_price} {settings.emoji_star}")
        lines.append(f"Уверенность оценки: {estimate.confidence}")
    else:
        lines.append("Рыночных данных по этим атрибутам пока нет — точную цену не посчитать.")

    lines.append("")
    for k, v in estimate.breakdown.items():
        lines.append(f"· {k}: {v}")

    await raw_api.edit_message_text(chat_id, target_message_id, "\n".join(lines), BACK_KB)
    await state.clear()


def _pct(permille: int | None) -> str:
    if not permille:
        return "редкость неизвестна"
    return f"{permille / 10:.1f}%"


async def main():
    await userbot.start()
    try:
        await dp.start_polling(bot)
    finally:
        await userbot.stop()


if __name__ == "__main__":
    asyncio.run(main())
