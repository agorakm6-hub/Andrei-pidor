"""
Прямые вызовы к api.telegram.org для фич, которые могут быть ещё не
полностью описаны в текущих версиях aiogram (цветные inline-кнопки
`style`, иконки `icon_custom_emoji_id`).

Если в твоей версии aiogram InlineKeyboardButton уже поддерживает
эти поля напрямую — можно смело выкинуть этот файл и использовать
обычные types.InlineKeyboardButton(...).
"""
from __future__ import annotations

import aiohttp
from typing import Any

from config import settings

API_ROOT = f"https://api.telegram.org/bot{settings.bot_token}"


def button(text: str, callback_data: str, style: str | None = None,
           icon_custom_emoji_id: str | None = None) -> dict[str, Any]:
    btn: dict[str, Any] = {"text": text, "callback_data": callback_data}
    if style:
        btn["style"] = style  # "primary" | "success" | "danger" | (default)
    if icon_custom_emoji_id:
        btn["icon_custom_emoji_id"] = icon_custom_emoji_id
    return btn


def keyboard(rows: list[list[dict[str, Any]]]) -> dict[str, Any]:
    return {"inline_keyboard": rows}


async def _post(method: str, payload: dict[str, Any]) -> dict[str, Any]:
    async with aiohttp.ClientSession() as session:
        async with session.post(f"{API_ROOT}/{method}", json=payload) as resp:
            data = await resp.json()
            if not data.get("ok"):
                raise RuntimeError(f"Telegram API error on {method}: {data}")
            return data["result"]


async def send_message(chat_id: int, text: str, reply_markup: dict | None = None) -> dict:
    payload: dict[str, Any] = {"chat_id": chat_id, "text": text, "parse_mode": "HTML"}
    if reply_markup:
        payload["reply_markup"] = reply_markup
    return await _post("sendMessage", payload)


async def edit_message_text(chat_id: int, message_id: int, text: str,
                             reply_markup: dict | None = None) -> dict:
    payload: dict[str, Any] = {
        "chat_id": chat_id,
        "message_id": message_id,
        "text": text,
        "parse_mode": "HTML",
    }
    if reply_markup:
        payload["reply_markup"] = reply_markup
    return await _post("editMessageText", payload)
