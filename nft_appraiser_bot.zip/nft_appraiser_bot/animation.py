import asyncio

import raw_api
from config import settings

_FRAMES = [
    f"Сканирую NFT {settings.emoji_scan}",
    f"Сканирую NFT {settings.emoji_scan}.",
    f"Сканирую NFT {settings.emoji_scan}..",
    f"Сканирую NFT {settings.emoji_scan}...",
]


class ScanAnimation:
    """Крутит анимацию в ОДНОМ сообщении (edit), пока не вызовут stop()."""

    def __init__(self, chat_id: int, message_id: int, interval: float = 0.6):
        self.chat_id = chat_id
        self.message_id = message_id
        self.interval = interval
        self._task: asyncio.Task | None = None
        self._stop = asyncio.Event()

    async def _run(self):
        i = 0
        while not self._stop.is_set():
            try:
                await raw_api.edit_message_text(self.chat_id, self.message_id, _FRAMES[i % len(_FRAMES)])
            except Exception:
                pass  # editMessageText кинет ошибку "message not modified" на дублях — это ок
            i += 1
            try:
                await asyncio.wait_for(self._stop.wait(), timeout=self.interval)
            except asyncio.TimeoutError:
                pass

    def start(self):
        self._task = asyncio.create_task(self._run())

    async def stop(self):
        self._stop.set()
        if self._task:
            await self._task
